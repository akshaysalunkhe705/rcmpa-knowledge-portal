@extends('layouts.layout',[
    'title'=>'Dashboard',
    'heading'=>'Dashboard',
    'breadcrumb1'=>'Dashboard',
    'breadcrumb2'=>'Dashboard',
    'nav_status'=>'Dashboard',
    'sub_nav_status'=>'Dashboard'
])
@section('main_container')

@endsection
