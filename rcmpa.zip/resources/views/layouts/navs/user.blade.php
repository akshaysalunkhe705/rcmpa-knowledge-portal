<li class="sidebar-menu-item @if ($nav_status=='doument-list' ) active open @endif">
    <a class="sidebar-menu-button js-sidebar-collapse" href="{{ url('user/document_list') }}">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        DOCUMENTS
    </a>
</li>