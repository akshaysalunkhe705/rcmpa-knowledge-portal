<li class="sidebar-menu-item @if ($nav_status=='general-master' ) active open @endif">
    <a class="sidebar-menu-button js-sidebar-collapse" href="{{ url('admin/general-master') }}">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        DOCUMENTS
    </a>
</li>

<li class="sidebar-menu-item @if ($nav_status=='general-master' ) active open @endif">
    <a class="sidebar-menu-button js-sidebar-collapse" data-toggle="collapse" href="#general-master">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        DOCUMENTS
        <span class="ml-auto sidebar-menu-toggle-icon"></span>
    </a>
    <ul class="sidebar-submenu collapse show sm-indent" id="general-master">
        <li class="sidebar-menu-item @if ($sub_nav_status=='location-index' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/capa/create') }}">
                <span class="sidebar-menu-text">CREATE NEW</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='department-index') active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/capa/update') }}">
                <span class="sidebar-menu-text">UPDATE OLD</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='form_master-index') active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/capa/roll_back') }}">
                <span class="sidebar-menu-text">ROLL BACK</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='maindocumentname-index' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/capa/deactivate') }}">
                <span class="sidebar-menu-text">DEACTIVATE</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='subdocumentname-index' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/capa/reactivate') }}">
                <span class="sidebar-menu-text">REACTIVATE</span>
            </a>
        </li>
    </ul>
</li>


<li class="sidebar-menu-item @if ($nav_status=='user' ) active open @endif">
    <a class="sidebar-menu-button js-sidebar-collapse" data-toggle="collapse" href="#user">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        DOCUMENT STATUS
        <span class="ml-auto sidebar-menu-toggle-icon"></span>
    </a>
    <ul class="sidebar-submenu collapse show sm-indent" id="user">
        <li class="sidebar-menu-item @if ($sub_nav_status=='user-add' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('user/user/add') }}">
                <span class="sidebar-menu-text">CREATE BUT NOT SUBMITED</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='user-fetch' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/user/fetch') }}">
                <span class="sidebar-menu-text">SUBMITTED BUT NOT APPROVED</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='user-fetch' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/user/fetch') }}">
                <span class="sidebar-menu-text">REJECTED FOR RESUBMITION</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='user-fetch' ) active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/user/fetch') }}">
                <span class="sidebar-menu-text">REJECTED FOR REMOVAL FROM CAPA</span>
            </a>
        </li>
    </ul>
</li>



<li class="sidebar-menu-item @if ($nav_status=='view' ) active open @endif">
    <a class="sidebar-menu-button js-sidebar-collapse" data-toggle="collapse" href="#view">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        VIEWS
        <span class="ml-auto sidebar-menu-toggle-icon"></span>
    </a>
    <ul class="sidebar-submenu collapse show sm-indent" id="view">
        <li class="sidebar-menu-item @if ($sub_nav_status=='view-active') active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/view/active_documents') }}">
                <span class="sidebar-menu-text">ACTIVE DOCS</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='view-deactive') active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/view/deactive_documents') }}">
                <span class="sidebar-menu-text">DEACTIVE DOCS</span>
            </a>
        </li>
        <li class="sidebar-menu-item @if ($sub_nav_status=='view-inactive') active @endif">
            <a class="sidebar-menu-button" href="{{ url('admin/view/inactive_documents') }}">
                <span class="sidebar-menu-text">ARCHIVED DOCS</span>
            </a>
        </li>
    </ul>
</li>