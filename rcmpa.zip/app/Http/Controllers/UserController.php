<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;

//Request
use Illuminate\Http\Request;
use App\Http\Requests\UserRequest;

//Models
use App\Models\User;
use App\Models\DepartmentModel;
use App\Models\RoleModel;
use App\Models\FormsModel;

//Interface

class UserController extends Controller
{
    public function login(Request $request)
    {
        if (Auth::check())
        {
            if(Auth::user()->role == "ADMIN"){ return redirect('admin/general-master'); }
            if(Auth::user()->role == "SUPER-ADMIN"){ return redirect('admin/general-master'); }
            return redirect('user/');
        }

        if ($request->isMethod('POST'))
        {
            if (Auth::attempt(['username' => $request->username, 'password' => $request->password]))
            {
                if(Auth::user()->role == "ADMIN"){ return redirect('admin/general-master'); }
                if(Auth::user()->role == "SUPER-ADMIN"){ return redirect('admin/general-master'); }
                return redirect('user/');
            }
            return "LOGIN ID PASSWORD WRONG...";
        }
        return view('user.login');
    }


    public function fetch()
    {
        $usersModel = User::all();
        $FormsModel = FormsModel::all();

        return view('user.fetch', [
            'users' => $usersModel,
            'formMasters' => $FormsModel
        ]);
    }

    public function detail($id)
    {
        $usersModel = User::find($id);
        $departmentDataset = DepartmentModel::all();
        $FormsModel = FormsModel::all();

        return view('user.detail', [
            'user' => $usersModel,
            'departmentDataset' => $departmentDataset,
            'FormsModel' => $FormsModel
        ]);
    }

    public function add(UserRequest $request)
    {
        $model = new User();
        if ($request->isMethod('POST')) {
            $model->add($request);
            return redirect()->back()->with('alert', 'User Added Successfuly...');
            return redirect('admin/user/fetch');
        }

        $departmentModel = DepartmentModel::all();
        $roleModel = RoleModel::all();
        return view('user.add', [
            'departments' => $departmentModel,
            'roles' => $roleModel
        ]);
    }

    public function edit()
    {
    }

    public function remove()
    {
    }
}
