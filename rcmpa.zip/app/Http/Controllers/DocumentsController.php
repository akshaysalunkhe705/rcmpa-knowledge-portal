<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DocumentsModel;

class DocumentsController extends Controller
{
    public function index($action)//action->permissions
    {

    }
    public function create()
    {

    }
    public function update()
    {

    }
    public function rollback()
    {

    }
    public function deactivate()
    {

    }
    public function reactivate()
    {

    }
}
