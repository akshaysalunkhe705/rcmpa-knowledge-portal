<?php

namespace App\Http\Controllers\GeneralMaster;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Models\LocationModel;
use App\Models\DepartmentModel;
use App\Models\MainDocumentTitleModel;
use App\Models\SubDocumentTitleModel;
use App\Models\FormsModel;

class GeneralMasterController extends Controller
{
    public function index()
    {
        $locationModel = LocationModel::all();
        $departmentModel = DepartmentModel::all();
        $mainDocumentTitleModel = MainDocumentTitleModel::all();
        $subDocumentTitleModel = SubDocumentTitleModel::all();
        $formsModel = FormsModel::all();

        return view('general_master/index', [
            'locationModel' => $locationModel,
            'departmentModel' => $departmentModel,
            'mainDocumentTitleModel' => $mainDocumentTitleModel,
            'subDocumentTitleModel' => $subDocumentTitleModel,
            'formsModel' => $formsModel
        ]);
    }
}
