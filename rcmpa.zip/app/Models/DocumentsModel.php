<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\BaseModelInterface;

class DocumentsModel extends Model implements BaseModelInterface
{
    use HasFactory, SoftDeletes;
    protected $table = "documents";
    protected $fillable = [
        'capa_number',
        'document_number',
        'location_id',
        'department_id',
        'form_id',
        'main_document_title_id',
        'sub_document_title_id',
        'prepared_by',
        'approved_by',
        'version_number',
        'created_date',
        'revision_date',
        'document_details',
        'status',
        'status_by_admin',
        'status_by_superadmin',
        'reject_note',
        'remove_note'
    ];


    public function add($request)
    {
        $model = $this->create([
            'capa_number' => $request->get('capa_number'),
            'document_number' => $request->get('document_number'),
            'location_id' => $request->get('location_id'),
            'department_id' => $request->get('department_id'),
            'form_id' => $request->get('form_id'),
            'main_document_title_id' => $request->get('main_document_title_id'),
            'prepared_by' => $request->get('prepared_by'),
            'approved_by' => $request->get('approved_by'),
            'version_number' => $request->get('version_number'),
            'created_date' => $request->get('created_date'),
            'revision_date' => $request->get('revision_date'),
            'document_details' => $request->get('document_details'),
            'status' => $request->get('status'),
            'status_by_admin' => $request->get('status_by_admin'),
            'status_by_superadmin' => $request->get('status_by_superadmin'),
            'reject_note' => $request->get('reject_note'),
            'remove_note' => $request->get('remove_note'),
        ]);
        return $model->save();
    }
    public function edit($request, $id)
    {
        $model1 = DocumentsModel::find($id);
        $model1->capa_number = $request->get('capa_number');
        $model1->document_number = $request->get('document_number');
        $model1->location_id = $request->get('location_id');
        $model1->department_id = $request->get('department_id');
        $model1->form_id = $request->get('form_id');
        $model1->main_document_title_id = $request->get('main_document_title_id');
        $model1->sub_document_title_id = $request->get('sub_document_title_id');
        $model1->prepared_by = $request->get('prepared_by');
        $model1->approved_by = $request->get('approved_by');
        $model1->version_number = $request->get('version_number');
        $model1->created_date = $request->get('created_date');
        $model1->revision_date = $request->get('revision_date');
        $model1->document_details = $request->get('document_details');
        $model1->status = $request->get('status');
        $model1->status_by_admin = $request->get('status_by_admin');
        $model1->status_by_superadmin = $request->get('status_by_superadmin');
        $model1->reject_note = $request->get('reject_note');
        $model1->remove_note = $request->get('remove_note');
        return $model1->save();
    }
    public function fetch_single($id)
    {
    }
    public function fetch_all()
    {
    }
    public function remove($id)
    {
    }
}
