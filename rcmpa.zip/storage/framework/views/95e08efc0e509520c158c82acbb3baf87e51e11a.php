

<?php $__env->startSection('main_container'); ?>
    <?php if(isset($alert)): ?>
        <div class="alert alert-success">
            <?php echo e(alert); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <br><br>
    <form action="<?php echo e(url('admin/user/add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <label for="department">Department</label>
                <select name="department" id="department" class="form-control" onchange="js:createUsername();">
                    <?php if(!empty($departments)): ?>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->department_name); ?>"><?php echo e($department->department_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control" onchange="js:createUsername();">
                    <?php if(!empty($roles)): ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->role_name); ?>"><?php echo e($role->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="navigation_type">Navigation Type</label>
                <select name="navigation_type" id="navigation_type" class="form-control">
                    <option value="USER">USER</option>
                    <option value="HOD">HOD</option>
                    <option value="ADMIN">ADMIN</option>
                </select>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Name"
                    onkeyup="js:createUsername();">
            </div>
            <div class="col-md-6">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username" placeholder="Username" readonly>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Password">
            </div>
            <div class="col-md-6">
                <br>
                <input type="submit" class="btn btn-success btn-block" value="Submit">
            </div>
        </div>
    </form>

    <script>
        function createUsername() {
            var department = $("#department").val();
            var role = $("#role").val();
            var name = $("#name").val();
            // department.slice(0,2)
            $("#username").val(department + "-" + role + "-" + name.split(" ")[0].toUpperCase());
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'User',
'heading' => 'User',
'breadcrumb1' => 'user',
'breadcrumb2' => 'add',
'nav_status' => 'user',
'sub_nav_status' => 'user-add',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/user/add.blade.php ENDPATH**/ ?>