<?php $__env->startSection('main_container'); ?>
    <?php $documentData = $dataSet->document_details; ?>
    <?php if (isset($component)) { $__componentOriginalb456e77e1f487f446e21d8c56757c7ee57843ba8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentViewHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-view-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb456e77e1f487f446e21d8c56757c7ee57843ba8)): ?>
<?php $component = $__componentOriginalb456e77e1f487f446e21d8c56757c7ee57843ba8; ?>
<?php unset($__componentOriginalb456e77e1f487f446e21d8c56757c7ee57843ba8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <br>
    <div>
        <label for="objective">Objective</label>
        <input type="text" name="objective" class="form-control" disabled>
    </div>
    <br>

    <label for="chemical_required_qc">Chemical Required</label>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Chemical Name</th>
                <th>Make</th>
                <th>Grade Purity</th>
                <th>Quantity</th>
                <th>Unit</th>
            </tr>
        </thead>
        <tbody id="chemical_required_qc">
            <tr>
                <td><input type="text" class="form-control" name="chemical_name[]" id="chemical_name" disabled></td>
                <td><input type="text" class="form-control" name="chemical_make[]" id="make" disabled></td>
                <td><input type="text" class="form-control" name="chemical_grade_purity[]" id="grade_purity" disabled></td>
                <td><input type="text" class="form-control" name="chemical_quantity[]" id="quantity" disabled></td>
                <td><input type="text" class="form-control" name="chemical_unit[]" id="unit" disabled></td>
            </tr>
        </tbody>
    </table>
    <br>

    <label for="apparatus_required">Apparatus Required</label>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <th>make</th>
                <th>model</th>
            </tr>
        </thead>
        <tbody id="apparatus_required">
            <tr>
                <td><input type="text" class="form-control" name="apparatus_name[]" id="name" disabled></td>
                <td><input type="text" class="form-control" name="apparatus_make[]" id="make" disabled></td>
                <td><input type="text" class="form-control" name="apparatus_model[]" id="model" disabled></td>
            </tr>
        </tbody>
    </table>
    <br>

    <label for="pre_testing ">Pre Testing</label>
    <textarea name="pre_testing" class="form-control" disabled><?php echo e($documentData['pre_testing']); ?></textarea>

    <label for="testing">Testing</label>
    <textarea name="testing" class="form-control" disabled><?php echo e($documentData['testing']); ?></textarea>

    <br>
    <label for="name_of_reference_document">Name Of Reference Document</label>
    <table class="table table-bordered">
        <tbody id="name_of_reference_document_qc">
            <tr>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
            </tr>
        </tbody>
    </table>
    <br>
    <label for="reference_document_urls">Reference Documents</label>
    <input type="file" name="reference_document_urls" class="form-control" disabled>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/formview_layout',
[
'title' => 'CAPA',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/document_form_views/sop_quality_control_form.blade.php ENDPATH**/ ?>