<?php $__env->startSection('main_container'); ?>

    <?php if(session('alert')): ?>
        <div class="alert alert-success">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>

    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            ROLE
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">
            <form action="<?php echo e(url('admin/general_master/role/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" name="role_name" id="" class="form-control" placeholder="Role">
                    </div>
                    <div class="col-md-4"></div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <br>

    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            LOCATION
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">

            <form action="<?php echo e(url('admin/general_master/location/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" name="location_name" id="" class="form-control" placeholder="Location">
                    </div>
                    <div class="col-md-4"></div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <br>

    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            DEPARTMENT
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">

            <form action="<?php echo e(url('admin/general_master/department/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <select name="location_id" id="" class="form-control">
                            <option value="">Select Location</option>
                            <?php $__currentLoopData = $locationModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->location_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="department_name" id="" class="form-control" placeholder="Department Name">
                    </div>
                    <div class="col-md-4"></div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>

    <br>
    <br>

    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            MAIN DOCUMENTS TITLES
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">

            <form action="<?php echo e(url('admin/general_master/main_document_title/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <select name="department_id" id="department_id" class="form-control">
                            <option value="">Select Department</option>
                            <?php $__currentLoopData = $departmentModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->department_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <select name="form_id" id="form_id" class="form-control">
                            <option value="">Select Form</option>
                            <?php $__currentLoopData = $formsModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->form_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="main_document_title" id="" class="form-control" placeholder="Main Document Name">
                    </div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <br>
    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            SUB DOCUMENTS TITLES
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">

            <form action="<?php echo e(url('admin/general_master/sub_document_title/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-3">
                        <select name="department_id" id="department_id" class="form-control">
                            <option value="">Select Department</option>
                            <?php $__currentLoopData = $departmentModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->department_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="main_document_id" id="main_document_id" class="form-control">
                            <option value="">Select Main Document Title</option>
                            <?php $__currentLoopData = $mainDocumentTitleModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->main_document_title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="sub_document_title" id="" class="form-control"
                            placeholder="Sub Document Title">
                    </div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>


    <div>
        <div style="box-shadow:0px -4px 5px #aaa; padding:0.6%;" class="bg-primary text-white font-weight-bold">
            UNIT
        </div>
        <div style="box-shadow:0px 4px 5px #aaa; padding:1%; background-color:white;">

            <form action="<?php echo e(url('admin/general_master/units/add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" name="unit_name" id="" class="form-control" placeholder="ADD UNIT">
                    </div>
                    <div class="col-md-4"></div>
                    <div class="col-md-2">
                        <input type="submit" value="submit" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'General Master',
'heading' => 'General Master',
'breadcrumb1' => 'general-master',
'breadcrumb2' => 'General Master',
'nav_status' => 'general-master',
'sub_nav_status' => 'department-general-master',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rcmpa\resources\views/general_master/index.blade.php ENDPATH**/ ?>