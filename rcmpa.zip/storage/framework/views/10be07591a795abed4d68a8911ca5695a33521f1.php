

<?php
use App\Models\MainDocumentTitleModel;
use App\Models\SubDocumentTitleModel;
?>

<?php $__env->startSection('main_container'); ?>
    <style>
        section {
            display: none;
            background-color: white;
            padding: 2%;
            box-shadow: 0px 0px 3px grey;
        }

        #process_flow_control {
            display: block;
        }

    </style>

    <?php if(count($process) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('process_flow_control')">PROCESS</button>
    <?php endif; ?>
    <?php if(count($sop_production) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('sop_production')">SOP (PRODUCTION)</button>
    <?php endif; ?>
    <?php if(count($sop_quality_control) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('sop_quality_control')">SOP (QUALITY CONTROL)</button>
    <?php endif; ?>
    <?php if(count($sop_maintenance) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('sop_maintenance')">SOP (MAINTENANCE)</button>
    <?php endif; ?>
    <?php if(count($msds) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('msds')">MSDS</button>
    <?php endif; ?>
    <?php if(count($sss) != 0): ?>
        <button class="btn btn-primary" onclick="js:sectionFormToggle('sss')">SSS</button>
    <?php endif; ?>

    <br><br>

    <section id="process_flow_control">
        <?php echo $__env->make('forms.process_and_flow_control_form',[
        'processDataset' => $process
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section id="sop_production">
        <?php echo $__env->make('forms.sop_production_form',[
        'sopProductionDataset' => $sop_production
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section id="sop_quality_control">
        <?php echo $__env->make('forms.sop_quality_control_form',[
        'sopQualityControlDataset' => $sop_quality_control
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section id="sop_maintenance">
        <?php echo $__env->make('forms.sop_maintenance_form',[
        'sopMaintenanceDataset' => $sop_maintenance
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section id="msds">
        <?php echo $__env->make('forms.msds_form',[
        'msdsDataset' => $msds
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <section id="sss">
        <?php echo $__env->make('forms.sss_form',[
        'sssDataset' => $sss
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>


    <script>
        function sectionFormToggle(section) {
            $('section').hide();
            $('#' + section).show();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'CAPA',
'heading' => 'CAPA',
'breadcrumb1' => 'CAPA',
'breadcrumb2' => 'New',
'nav_status' => 'document_action',
'sub_nav_status' => 'document_action-set-create',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/capa/create.blade.php ENDPATH**/ ?>