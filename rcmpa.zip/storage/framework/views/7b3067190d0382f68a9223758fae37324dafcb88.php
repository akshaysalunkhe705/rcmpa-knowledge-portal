<?php
use App\Models\DocumentModel;
use App\Models\SubDocumentModel;
use App\Models\DepartmentModel;
?>





<?php $__env->startSection('main_container'); ?>
    <table class="table">
        <tr>
            <th>department</th>
            <th>role</th>
            <th>name</th>
            <th>username</th>
            
            <th>Set Permissions</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->department); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->username); ?></td>
                
                <td>
                    <a class="btn btn-info" href="<?php echo e(url('admin/user/detail')); ?>/<?php echo e($user->id); ?>">Set Permissions</a>
                </td>
                <th>
                    <button class="btn" data-toggle="modal" data-target="#set-permission-<?php echo e($user->id); ?>">View
                        Permissions</button> | <a class="btn" href="">Delete</a></th>
            </tr>
            <div class="modal fade" id="set-permission-<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="set-permission-<?php echo e($user->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="set-permission-<?php echo e($user->id); ?>">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <?php $__currentLoopData = $formMasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formMaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div onclick="js:toggleSlide(<?php echo e($user->id); ?>,<?php echo e($formMaster->id); ?>)"
                                            class="border p-1" style="font-weight:bold">
                                            <?php echo e($formMaster->form_name); ?>

                                        </div>
                                        <div id="form-master-<?php echo e($user->id); ?>-<?php echo e($formMaster->id); ?>"
                                            class="form-master border p-1" style="display: none">
                                            <p>
                                                <input type="checkbox" name="" checked disabled> Create/update/Rollback Document |<br>
                                                <input type="checkbox" name="" disabled> View Active Documents |<br>
                                                <input type="checkbox" name="" checked disabled> View Rejected Documents |<br>
                                                <input type="checkbox" name="" checked disabled> View Archived Documents |<br>
                                                <input type="checkbox" name="" checked disabled> View Pending Documents |<br>
                                                <input type="checkbox" name="" disabled> Deactivate Documents |<br>
                                                <input type="checkbox" name="" disabled> View CAPA status |<br>
                                            </p>
                                        </div>
                                        <br>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <style>
        .modal-backdrop.fade.show {
            display: none;
        }

    </style>
    <script>
        function toggleSlide(user_id, id) {
            $("#form-master-" + user_id + "-" + id).slideToggle();
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'User',
'heading' => 'User',
'breadcrumb1' => 'user',
'breadcrumb2' => 'list',
'nav_status' => 'user',
'sub_nav_status' => 'user-fetch',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rcmpa\resources\views/user/fetch.blade.php ENDPATH**/ ?>