<?php $__env->startSection('main_container'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout',[
    'title'=>'Dashboard',
    'heading'=>'Dashboard',
    'breadcrumb1'=>'Dashboard',
    'breadcrumb2'=>'Dashboard',
    'nav_status'=>'Dashboard',
    'sub_nav_status'=>'Dashboard'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/welcome.blade.php ENDPATH**/ ?>