<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo e($title); ?></title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex" />

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap"
        rel="stylesheet" />
    <!-- Preloader -->
    <link type="text/css" href="<?php echo e(url('vendor/spinkit.css')); ?>" rel="stylesheet" />
    <!-- Perfect Scrollbar -->
    <link type="text/css" href="<?php echo e(url('vendor/perfect-scrollbar.css')); ?>" rel="stylesheet" />
    <!-- Material Design Icons -->
    <link type="text/css" href="<?php echo e(url('css/material-icons.css')); ?>" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <link type="text/css" href="<?php echo e(url('css/fontawesome.css')); ?>" rel="stylesheet" />
    <!-- Preloader -->
    <link type="text/css" href="<?php echo e(url('css/preloader.css')); ?>" rel="stylesheet" />
    <!-- App CSS -->
    <link type="text/css" href="<?php echo e(url('css/app.css')); ?>" rel="stylesheet" />

    <!-- jQuery -->
    <script src="<?php echo e(url('/vendor/jquery.min.js')); ?>"></script>

    <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.16.0/standard-all/ckeditor.js"></script>
</head>

<body class="layout-app">
    <div class="preloader">
        <div class="sk-chase">
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
            <div class="sk-chase-dot"></div>
        </div>
    </div>

    <!-- Drawer Layout -->
    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">
            <!-- Header -->

            <!-- Navbar -->
            <div class="navbar navbar-expand pr-0 navbar-light border-bottom-2" id="default-navbar" data-primary>
                <!-- Navbar Toggler -->
                <button class="navbar-toggler w-auto mr-16pt d-block d-lg-none rounded-0" type="button"
                    data-toggle="sidebar">
                    <span class="material-icons">short_text</span>
                </button>
                <!-- // END Navbar Toggler -->

                <!-- Navbar Brand -->
                <a href="index.html" class="navbar-brand mr-16pt d-lg-none">
                    <span class="avatar avatar-sm navbar-brand-icon mr-0 mr-lg-8pt">
                        <span class="avatar-title rounded bg-primary">
                            <img src="<?php echo e(url('website-images/logo.jpeg')); ?>" alt="logo" class="img-fluid" /></span>
                    </span>

                    <span class="d-none d-lg-block"></span>
                </a>

                <!-- // END Navbar Brand -->

                <div class="flex"></div>

                <!-- Switch Layout -->

                <a href="https://luma.humatheme.com/Demos/Compact_App_Layout/billing.html"
                    class="navbar-toggler navbar-toggler-custom align-items-center justify-content-center d-none d-lg-flex"
                    data-toggle="tooltip" data-title="Switch to Compact Layout" data-placement="bottom"
                    data-boundary="window">
                    <span class="material-icons">swap_horiz</span>
                </a>

                <!-- // END Switch Layout -->

                <!-- Navbar Menu -->

                
                <div class="nav navbar-nav flex-nowrap d-flex mr-16pt">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link d-flex align-items-center dropdown-toggle" data-toggle="dropdown"
                            data-caret="false">
                            <span class="avatar avatar-sm mr-8pt2">
                                <span class="avatar-title rounded-circle bg-primary"><i
                                        class="material-icons">account_box</i></span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            
                            
                            <a class="dropdown-item active" href="<?php echo e(url('/logout')); ?>">Logout</a>
                        </div>
                    </div>
                </div>

                <!-- // END Navbar Menu -->
            </div>

            <!-- // END Navbar -->

            <!-- // END Header -->

            <div class="pt-12pt">
                <div
                    class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center">
                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0"><?php echo e($heading); ?></h2>
                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item"><?php echo e($breadcrumb1); ?></li>
                                <li class="breadcrumb-item active"><?php echo e($breadcrumb2); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <!-- BEFORE Page Content -->

            <!-- // END BEFORE Page Content -->

            <!-- Page Content -->

            <div class="page-section page__container">
                <div class="shadow-sm p-3 bg-light">
                    <?php echo $__env->yieldContent('main_container'); ?>
                </div>
            </div>

            <!-- // END Page Content -->

            <!-- Footer -->

            <div class="bg-white border-top-2 mt-auto">
                <div class="container page__container d-flex flex-column" style="padding: 1rem;">
                    <p class="text-50 small mt-n1 mb-0">
                        <a href="#" class="text-70 text-underline mr-8pt small">Terms</a>
                        <a href="#" class="text-70 text-underline mr-8pt small">Privacy policy</a>
                        Copyright <?= date('Y') ?> &copy; All rights reserved.</p>
          </div>
        </div>
        <!-- // END Footer -->
      </div>

      <!-- // END drawer-layout__content -->

      <!-- Drawer -->

      <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
        <div class="mdk-drawer__content">
          <div class="sidebar sidebar-dark-pickled-bluewood sidebar-left" data-perfect-scrollbar>
            <!-- Sidebar Content -->
            <a href="index.html" class="sidebar-brand" style="padding:1rem 0;">
              <span class="avatar avatar-xl sidebar-brand-icon h-auto">
                <span class="avatar-title rounded bg-primary"
                  ><img
                    src="<?php echo e(url('website-images/logo.jpeg')); ?>"
                    class="img-fluid"
                    alt="logo"
                /></span>
              </span>
              <span>RCMPA</span>
            </a>
            <p class="text-center"><?php echo e(Auth::user()->name); ?> <br> (<?php echo e(Auth::user()->department); ?>)</p>

            <div class="sidebar-heading">Navigation</div>
            <ul class="sidebar-menu">

                <?php if(Auth::user()->navigation_type == 'ADMIN'): ?>
                    <?php echo $__env->make('layouts.navs.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Auth::user()->navigation_type == 'HOD'): ?>
                    <?php echo $__env->make('layouts.navs.hod', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Auth::user()->navigation_type == 'USER'): ?>
                    <?php echo $__env->make('layouts.navs.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </ul>
            </div>
        </div>
      </div>

      <!-- // END Drawer -->
    </div>

    <!-- // END Drawer Layout -->

    <!-- Bootstrap -->
    <script src="<?php echo e(url('/vendor/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('/vendor/bootstrap.min.js')); ?>"></script>
    <!-- Perfect Scrollbar -->
    <script src="<?php echo e(url('/vendor/perfect-scrollbar.min.js')); ?>"></script>
    <!-- DOM Factory -->
    <script src="<?php echo e(url('/vendor/dom-factory.js')); ?>"></script>
    <!-- MDK -->
    <script src="<?php echo e(url('/vendor/material-design-kit.js')); ?>"></script>
    <!-- App JS -->
    <script src="<?php echo e(url('/js/app.js')); ?>"></script>
    <!-- Preloader -->
    <script src="<?php echo e(url('/js/preloader.js')); ?>"></script>

    <style>
      .flex.justify-between.flex-1{
        display: none;
      }
      .w-5.h-5{
        width: 35px;
      }
    </style>
  </body>
</html>
<?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/layouts/layout.blade.php ENDPATH**/ ?>