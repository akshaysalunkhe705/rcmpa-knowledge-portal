<?php $frommasterCount = count($formMasters); ?>

<?php $__env->startSection('main_container'); ?>

    <?php if(session('alert')): ?>
        <div class="alert alert-success">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>


    <form action="<?php echo e(url('admin/general_master/forms/add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="form_name" id="form_name" class="form-control" placeholder="Form Master Name">
            </div>
            <div class="col-md-4">
                <select type="checkbox" name="sequence" id="" class="form-control">
                    <?php for($i = $frommasterCount + 1; $i >= 1; --$i): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="submit" class="btn btn-info btn-block">
            </div>
        </div>
    </form>
    <br>
    <br>
    <table class="table">
        <tr>
            <th>Id</th>
            <th>Sequence</th>
            <th>Form Master</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $formMasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td>
                    <select type="checkbox" name="sequence" id="sequence-<?php echo e($item->id); ?>" class="form-control">
                        <option value="<?php echo e($item->sequence); ?>" selected="selected"><?php echo e($item->sequence); ?></option>
                        <?php for($i = 1; $i <= $frommasterCount; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </td>
                <td><input type="text" name="form_name" id="form_master-<?php echo e($item->id); ?>" class="form-control"
                        value="<?php echo e($item->form_name); ?>"></td>
                <td><button class="btn" onclick="edit(<?php echo e($item->id); ?>);">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    <script>
        function edit(id) {
            var form_master = $("#form_master-" + id).val();
            var sequence = $("#sequence-" + id).val();
            $.get('http://localhost:8000/admin/general_master/forms/edit/' + id, {
                'form_name': form_master,
                'sequence': sequence
            }, function(response) {
                console.log(response);
                alert("Form Edited Successfully");

            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'Form Master',
'heading' => 'Form Master',
'breadcrumb1' => 'form_master',
'breadcrumb2' => 'fetch',
'nav_status' => 'general-master',
'sub_nav_status' => 'form_master-index',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rcmpa\resources\views/general_master/form/index.blade.php ENDPATH**/ ?>