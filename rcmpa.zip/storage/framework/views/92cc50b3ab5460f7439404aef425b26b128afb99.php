<?php
use App\Models\DepartmentModel;
use App\Models\FormsModel;
use App\Models\MainDocumentTitleModel;
?>

<?php $__env->startSection('main_container'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-success">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('admin/general_master/sub_document_title/add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-2">
                <select name="department_id" id="department_id" class="form-control">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="form_id" id="form_id" class="form-control">
                    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($form_master->id); ?>"><?php echo e($form_master->form_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="main_document_id" id="main_document_id" class="form-control">
                    <?php $__currentLoopData = $mainDocumentTitleModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maindocumentname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($maindocumentname->id); ?>"><?php echo e($maindocumentname->main_document_title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <input type="text" name="sub_document_title" id="sub_document_title" class="form-control"
                    placeholder="Sub Document Title">
            </div>
            <div class="col-md-2">
                <input type="submit" value="submit" class="btn btn-info">
            </div>
        </div>
    </form>
    <br>
    <br>
    <table class="table">
        <tr>
            <th>Id</th>
            <th>Department</th>
            <th>Form Master</th>
            <th>Main Document Name</th>
            <th>Sub Document Name</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $subDocumentTitleModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" value="<?php echo e($item->department_id); ?>" id="department_id-<?php echo e($item->id); ?>">
            <input type="hidden" value="<?php echo e($item->form_id); ?>" id="form_id-<?php echo e($item->id); ?>">
            <input type="hidden" value="<?php echo e($item->main_document_id); ?>" id="main_document_id-<?php echo e($item->id); ?>">
            <?php
            $department = DepartmentModel::find($item->department_id);
            $formMaster = FormsModel::find($item->form_id);
            $maindocumentname = MainDocumentTitleModel::find($item->main_document_id);
            ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($department->department_name); ?></td>
                <td><?php echo e($formMaster->form_name); ?></td>
                <td><?php echo e($maindocumentname->main_document_title); ?></td>
                <td><input type="text" name="" id="document-<?php echo e($item->id); ?>" class="form-control"
                        value="<?php echo e($item->sub_document_title); ?>"></td>
                <td><button class="btn" onclick="edit(<?php echo e($item->id); ?>)">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <script>
        function edit(id) {
            var document = $("#document-" + id).val();
            var department_id = $("#department_id-" + id).val();
            var form_id = $("#form_id-" + id).val();
            var main_document_id = $("#main_document_id-" + id).val();
            $.get('http://localhost:8000/admin/general_master/sub_document_title/edit/' + id, {
                'sub_document_title': document,
                'department_id': department_id,
                'form_id': form_id,
                'main_document_id': main_document_id,
            }, function(response) {
                console.log(response);
                alert("Sub Document Edited Successfully");
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'document',
'heading' => 'Sub Document Name',
'breadcrumb1' => 'document',
'breadcrumb2' => 'index',
'nav_status' => 'general-master',
'sub_nav_status' => 'subdocumentname-index',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rcmpa\resources\views/general_master/sub_document_name/index.blade.php ENDPATH**/ ?>