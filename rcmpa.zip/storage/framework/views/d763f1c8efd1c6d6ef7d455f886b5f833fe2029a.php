<?php $__currentLoopData = $sssDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$documentData = $dataSet->document_details;
?>
    <form action="<?php echo e(url('hod/capa_actions/sss')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <br>
        <label for="">Client Name</label>
        <input type="text" name="client_name" id="client_name" class="form-control" value="<?php echo e($dataSet->client_name); ?>">
        <br>
        <button class="btn btn-primary" onclick="js:add_sss_parameters();">+</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Parameter</th>
                    <th>Specification</th>
                    <th>Units</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody id="sss_parameters">
                <?php if($documentData != null): ?>
                    <?php for($i = 0; $i < count($documentData['identification']['parameter']); $i++): ?>
                    <tr>
                        <td>
                            <input type="text" name="parameter[]" id="parameter[]" class="form-control" value="<?php echo e($documentData['identification']['parameter'][$i]); ?>">
                        </td>
                        <td>
                            <input type="text" name="specification[]" id="specification[]" class="form-control" value="<?php echo e($documentData['identification']['specification'][$i]); ?>">
                        </td>
                        <td>
                            <input type="text" name="units[]" id="units[]" class="form-control" value="<?php echo e($documentData['identification']['units'][$i]); ?>">
                        </td>
                        <td>
                            <input type="text" name="remark[]" id="remark[]" class="form-control" value="<?php echo e($documentData['identification']['remark'][$i]); ?>">
                        </td>
                    </tr>
                    <?php endfor; ?>
                <?php endif; ?>
                <tr>
                    <td>
                        <input type="text" name="parameter[]" id="parameter" class="form-control" >
                    </td>
                    <td>
                        <input type="text" name="specification[]" id="specification" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="units[]" id="units" class="form-control">
                    </td>
                    <td>
                        <input type="text" name="remark[]" id="remark" class="form-control">
                    </td>
                </tr>
            </tbody>
        </table>

        <hr>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormFooterComponent::class, ['status' => ''.e($dataSet->status).'','statusByAdmin' => ''.e($dataSet->status_by_admin).'','statusBySuperAdmin' => ''.e($dataSet->status_by_super_admin).'','rejectNote' => ''.e($dataSet->reject_note).'','removedNote' => ''.e($dataSet->removed_note).'']); ?>
<?php $component->withName('document-form-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38)): ?>
<?php $component = $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38; ?>
<?php unset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <br>
        <input type="submit" name="SAVE" class="btn btn-primary" value="SAVE">
        <input type="submit" name="SUBMIT" class="btn btn-primary" value="SUBMIT">
    </form>

    <script>
        
    function add_sss_parameters() {
        event.preventDefault();
        $("#sss_parameters").after(`
            <tr>
                <td>
                    <input type="text" name="parameter[]" id="parameter" class="form-control" >
                </td>
                <td>
                    <input type="text" name="specification[]" id="specification" class="form-control">
                </td>
                <td>
                    <input type="text" name="units[]" id="units" class="form-control">
                </td>
                <td>
                    <input type="text" name="remark[]" id="remark" class="form-control">
                </td>
            </tr>
        `);
        return false;
    }
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/forms/sss_form.blade.php ENDPATH**/ ?>