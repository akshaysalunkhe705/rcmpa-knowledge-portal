<?php $__currentLoopData = $sopMaintenanceDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $documentData = $dataSet->document_details; ?>
    <form action="<?php echo e(url('hod/capa_actions/sop_maintenance/')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>

        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <br>
        <label for="purpose">Purpose</label>
        <textarea name="purpose" id="purpose" class="form-control"><?php echo e($documentData['purpose']); ?></textarea>
        <br>
        <label for="scope">scope</label>
        <textarea name="scope" id="scope" class="form-control"><?php echo e($documentData['scope']); ?></textarea>
        <br>
        <label for="responsibility">responsibility</label>
        <textarea name="responsibility" id="responsibility"
            class="form-control"><?php echo e($documentData['responsibility']); ?></textarea>
        <br>
        <label for="accountability">accountability</label>
        <textarea name="accountability" id="accountability"
            class="form-control"><?php echo e($documentData['accountability']); ?></textarea>
        <br>
        <label for="defination">defination</label>
        <textarea name="defination" id="defination" class="form-control"><?php echo e($documentData['defination']); ?></textarea>
        <br>
        <label for="procedures">procedures</label>
        <textarea name="procedures" id="procedures" class="form-control"><?php echo e($documentData['procedures']); ?></textarea>
        <br>
        <label for="precautions">precautions</label>
        <textarea name="precautions" id="precautions"
            class="form-control"><?php echo e($documentData['precautions']); ?></textarea>
        <br>
        <label for="applicable_formats_reference">applicable_formats_reference</label>
        <textarea name="applicable_formats_reference" id="applicable_formats_reference"
            class="form-control"><?php echo e($documentData['applicable_formats_reference']); ?></textarea>
        <br>
        <label for="abbrevations">abbrevations</label>
        <textarea name="abbrevations" id="abbrevations"
            class="form-control"><?php echo e($documentData['abbrevations']); ?></textarea>
        <br>
        <label for="document_history">document_history</label>
        <textarea name="document_history" id="document_history"
            class="form-control"><?php echo e($documentData['document_history']); ?></textarea>
        <br>
        <label for="reference_document_urls">reference_document</label>
        <input type="file" name="reference_document_urls" class="form-control">

        <br>
        <label for="name_of_reference_document">Name Of Reference Document</label><button class="btn btn-primary"
            onclick="js:add_name_of_reference_document();">+</button>
        <table class="table table-bordered">
            <tbody id="name_of_reference_document_sopM">
                <?php if($documentData != null): ?>
                    <tr>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $documentData['name_of_reference_document']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($i % 3) == 0): ?>
                                <?php $i=0; ?>
                                </tr><tr>
                            <?php endif; ?>
                            <?php $i++ ?>
                            <td>
                                <input type="text" name="name_of_reference_document[]" class="form-control" value="<?php echo e($item); ?>">
                            </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <br>

        <hr>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormFooterComponent::class, ['status' => ''.e($dataSet->status).'','statusByAdmin' => ''.e($dataSet->status_by_admin).'','statusBySuperAdmin' => ''.e($dataSet->status_by_super_admin).'','rejectNote' => ''.e($dataSet->reject_note).'','removedNote' => ''.e($dataSet->removed_note).'']); ?>
<?php $component->withName('document-form-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38)): ?>
<?php $component = $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38; ?>
<?php unset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <br>
        <input type="submit" name="SAVE" class="btn btn-primary" value="SAVE">
        <input type="submit" name="SUBMIT" class="btn btn-primary" value="SUBMIT">
    </form>

    <script>
        function add_name_of_reference_document() {
            event.preventDefault();
            $("#name_of_reference_document_sopM").after(`
                <tr>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                </tr>`);
            return false;
        }

    </script>

    <script>
        CKEDITOR.replace('purpose', {});
        CKEDITOR.replace('scope', {});
        CKEDITOR.replace('responsibility', {});
        CKEDITOR.replace('accountability', {});
        CKEDITOR.replace('defination', {});
        CKEDITOR.replace('procedures', {});
        CKEDITOR.replace('precautions', {});
        CKEDITOR.replace('applicable_formats_reference', {});
        CKEDITOR.replace('abbrevations', {});
        CKEDITOR.replace('document_history', {});
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/forms/sop_maintenance_form.blade.php ENDPATH**/ ?>