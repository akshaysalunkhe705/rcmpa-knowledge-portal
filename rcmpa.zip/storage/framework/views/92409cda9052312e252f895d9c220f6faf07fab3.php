<?php $__env->startSection('main_container'); ?>
    <?php if(session('alert')): ?>
        <div class="alert alert-success">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('admin/general_master/location/add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="location_name" id="" class="form-control" placeholder="Location Name">
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-2">
                <input type="submit" value="submit" class="btn btn-info">
            </div>
        </div>
    </form>
    <br>
    <br>
    <table class="table">
        <tr>
            <th>Id</th>
            <th>Location</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $locationDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><input type="text" name="" id="location-<?php echo e($item->id); ?>" class="form-control"
                        value="<?php echo e($item->location_name); ?>"></td>
                <td><button class="btn" onclick="edit(<?php echo e($item->id); ?>);">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <script>
        function edit(id)
        {
            var location = $("#location-" + id).val();
            $.get('http://localhost:8000/admin/general_master/location/edit/' + id, {
                'location_name': location
            }, function(response) {
                console.log(response);
                alert("Location Edited Successfully");
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'Location',
'heading' => 'Location',
'breadcrumb1' => 'Location',
'breadcrumb2' => 'index',
'nav_status' => 'general-master',
'sub_nav_status' => 'location-index',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/general_master/location/index.blade.php ENDPATH**/ ?>