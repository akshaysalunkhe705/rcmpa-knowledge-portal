<?php $__currentLoopData = $msdsDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$documentData = $dataSet->document_details;
?>
    <form action="<?php echo e(url('hod/capa_actions/msds')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <br>
        <label for="identification">identification</label>
        <div class="row">
            <div class="col-md-4">Product Idenitifer</div>
            <div class="col-md-4">
                <input type="text" name="product_identification" id="product_identification" class="form-control" value="<?php echo e($documentData['identification']['product_identification']); ?>">
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Product Code</div>
            <div class="col-md-4">
                <input type="text" name="product_code" id="product_code" class="form-control" value="<?php echo e($documentData['identification']['product_code']); ?>">
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Physical Appearance</div>
            <div class="col-md-4">
                <input type="text" name="physical_appearance" id="physical_appearance" class="form-control" value="<?php echo e($documentData['identification']['physical_appearance']); ?>">
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">CAS Number</div>
            <div class="col-md-4">
                <input type="text" name="CAS_number" id="CAS_number" class="form-control" value="<?php echo e($documentData['identification']['CAS_number']); ?>">
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Relevant Identified Uses Of Substance</div>
            <div class="col-md-4">
                <input type="text" name="relevant_identified_uses_of_substance"
                    id="relevant_identified_uses_of_substance" class="form-control" value="<?php echo e($documentData['identification']['relevant_identified_uses_of_substance']); ?>">
            </div>
        </div>

        <br>
        <label for="hazards_identification">Hazards Identification</label>
        <?php 
            print_r($documentData['hazards_identification']);
        ?>
        <textarea name="hazards_identification" id="hazards_identification" class="form-control"><?php echo e($documentData['hazards_identification']); ?></textarea>
        <br>
        <label for="composition_information_or_ingredients">Composition Information/Ingredients</label>
        <textarea name="composition_information_or_ingredients" id="composition_information_or_ingredients" class="form-control"><?php echo e($documentData['composition_information_or_ingredients']); ?></textarea>
        <br>
        <label for="first_and_measures">First And Measures</label>
        <textarea name="first_and_measures" id="first_and_measures" class="form-control"><?php echo e($documentData['first_and_measures']); ?></textarea>
        <br>
        <label for="firefighting_measures">Firefighting Measures</label>
        <textarea name="firefighting_measures" id="firefighting_measures" class="form-control"><?php echo e($documentData['firefighting_measures']); ?></textarea>
        <br>
        <label for="accidental_release_measures">Accidental Release Measures</label>
        <textarea name="accidental_release_measures" id="accidental_release_measures" class="form-control"><?php echo e($documentData['accidental_release_measures']); ?></textarea>
        <br>
        <label for="handling_and_storage">Handling And Storage</label>
        <textarea name="handling_and_storage" id="handling_and_storage" class="form-control"><?php echo e($documentData['handling_and_storage']); ?></textarea>
        <br>
        <label for="exposure_control_or_personal_protection">Exposure Control/Personal Protection</label>
        <textarea name="exposure_control_or_personal_protection" id="exposure_control_or_personal_protection" class="form-control"><?php echo e($documentData['exposure_control_or_personal_protection']); ?></textarea>
        <br>
        <label for="physical_and_chemical_properties">Physical And Chemical Properties</label>
        <textarea name="physical_and_chemical_properties" id="physical_and_chemical_properties" class="form-control"><?php echo e($documentData['physical_and_chemical_properties']); ?></textarea>
        <br>
        <label for="stability_and_reactivity">Stability And Reactivity</label>
        <textarea name="stability_and_reactivity" id="stability_and_reactivity" class="form-control"><?php echo e($documentData['stability_and_reactivity']); ?></textarea>
        <br>
        <label for="toxiocological_information">Toxiocological Information</label>
        <textarea name="toxiocological_information" id="toxiocological_information" class="form-control"><?php echo e($documentData['toxiocological_information']); ?></textarea>

        <hr>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormFooterComponent::class, ['status' => ''.e($dataSet->status).'','statusByAdmin' => ''.e($dataSet->status_by_admin).'','statusBySuperAdmin' => ''.e($dataSet->status_by_super_admin).'','rejectNote' => ''.e($dataSet->reject_note).'','removedNote' => ''.e($dataSet->removed_note).'']); ?>
<?php $component->withName('document-form-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38)): ?>
<?php $component = $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38; ?>
<?php unset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <br>
        <input type="submit" name="SAVE" class="btn btn-primary" value="SAVE">
        <input type="submit" name="SUBMIT" class="btn btn-primary" value="SUBMIT">
    </form>

    <script>
        CKEDITOR.replace('hazards_identification', {});
        CKEDITOR.replace('composition_information_or_ingredients', {});
        CKEDITOR.replace('first_and_measures', {});
        CKEDITOR.replace('firefighting_measures', {});
        CKEDITOR.replace('accidental_release_measures', {});
        CKEDITOR.replace('handling_and_storage', {});
        CKEDITOR.replace('exposure_control_or_personal_protection', {});
        CKEDITOR.replace('physical_and_chemical_properties', {});
        CKEDITOR.replace('stability_and_reactivity', {});
        CKEDITOR.replace('toxiocological_information', {});
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/forms/msds_form.blade.php ENDPATH**/ ?>