<?php $__currentLoopData = $sopProductionDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $documentData = $dataSet->document_details; ?>
    <form action="<?php echo e(url('hod/capa_actions/sop_production')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <div>
            <label for="objective">Objective</label>
            <input type="text" name="objective" class="form-control">
        </div>

        <br>
        <label for="chemical_required">Chemical Required</label><button class="btn btn-primary"
            onclick="js:add_chemical_required_pr();">+</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Chemical Name</th>
                    <th>Make</th>
                    <th>Grade Purity</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                </tr>
            </thead>
            <tbody id="chemical_required_PR">
                <tr>
                    <td><input class="form-control" type="text" name="chemical_name[]" id="chemical_name"></td>
                    <td><input class="form-control" type="text" name="chemical_make[]" id="make"></td>
                    <td><input class="form-control" type="text" name="chemical_grade_purity[]" id="grade_purity"></td>
                    <td><input class="form-control" type="text" name="chemical_quantity[]" id="quantity"></td>
                    <td><input class="form-control" type="text" name="chemical_unit[]" id="unit"></td>
                </tr>
            </tbody>
        </table>
        <br>
        <label for="equipment_required">Equipment Required</label><button class="btn btn-primary"
            onclick="js:add_equipment_required_pr();">+</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Location Mark And Number</th>
                    <th>Capacity</th>
                    <th>Unit</th>
                </tr>
            </thead>
            <tbody id="equipment_required_PR">
                <tr>
                    <td><input class="form-control" type="text" name="equipement_name[]" id="name"></td>
                    <td><input class="form-control" type="text" name="equipement_location_mark_and_number[]" id="location_mark_and_number"></td>
                    <td><input class="form-control" type="text" name="equipement_capacity[]" id="capacity"></td>
                    <td><input class="form-control" type="text" name="equipement_unit[]" id="unit"></td>
                </tr>
            </tbody>
        </table>
        <br>

        <label for="pre_production_process">Pre Production Process</label>
        <input type="text" name="pre_production_process" class="form-control">

        <label for="production_process">Production Process</label>
        <input type="text" name="production_process" class="form-control">

        <label for="post_production_process">Post Production Process</label>
        <input type="text" name="post_production_process" class="form-control">

        <label for="reference_document_urls">Reference Document Urls</label>
        <input type="text" name="reference_document_urls" class="form-control">

        <br>
        <label for="name_of_reference_document">Name Of Reference Document</label><button class="btn btn-primary"
            onclick="js:add_name_of_reference_document();">+</button>
        <table class="table table-bordered">
            <tbody id="name_of_reference_document_sop_PR">
                <?php if($documentData['name_of_reference_document'] != null): ?>
                    <tr>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $documentData['name_of_reference_document']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i % 3 == 0): ?>
                                <?php $i = 0; ?>
                                    </tr>
                                    <tr>
                                <?php endif; ?>
                                <?php $i++; ?>
                                <td>
                                    <input type="text" name="name_of_reference_document[]" class="form-control"
                                        value="<?php echo e($item); ?>">
                                </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                    <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                </tr>
            </tbody>
        </table>

<label for="reference_document_urls">Reference Document Upload</label>
<input type="file" name="reference_document_urls" class="form-control" multiple>
<br>

<hr>
<div style="border:1px solid; padding:1%;">
    <?php if (isset($component)) { $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormFooterComponent::class, ['status' => ''.e($dataSet->status).'','statusByAdmin' => ''.e($dataSet->status_by_admin).'','statusBySuperAdmin' => ''.e($dataSet->status_by_super_admin).'','rejectNote' => ''.e($dataSet->reject_note).'','removedNote' => ''.e($dataSet->removed_note).'']); ?>
<?php $component->withName('document-form-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38)): ?>
<?php $component = $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38; ?>
<?php unset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>
<br>
<input type="submit" name="SAVE" class="btn btn-primary" value="SAVE">
<input type="submit" name="SUBMIT" class="btn btn-primary" value="SUBMIT">
</form>
<script>
    function add_chemical_required_pr() {
        event.preventDefault();
        $("#chemical_required_PR").after(`
            <tr>
                <td><input class="form-control" type="text" name="chemical_name[]" id="chemical_name"></td>
                <td><input class="form-control" type="text" name="make[]" id="make"></td>
                <td><input class="form-control" type="text" name="grade_purity[]" id="grade_purity"></td>
                <td><input class="form-control" type="text" name="quantity[]" id="quantity"></td>
                <td><input class="form-control" type="text" name="unit[]" id="unit"></td>
            </tr>`);
        return false;
    }

    function add_equipment_required_pr() {
        event.preventDefault();
        $("#equipment_required_PR").after(`
            <tr>
                <td><input class="form-control" type="text" name="equipement_name[]" id="name"></td>
                <td><input class="form-control" type="text" name="equipement_location_mark_and_number[]" id="location_mark_and_number"></td>
                <td><input class="form-control" type="text" name="equipement_capacity[]" id="capacity"></td>
                <td><input class="form-control" type="text" name="equipement_unit[]" id="unit"></td>
            </tr>`);
        return false;
    }

    function add_name_of_reference_document() {
        event.preventDefault();
        $("#name_of_reference_document_sop_PR").after(`
            <tr>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
                <td><input type="text" class="form-control" name="name_of_reference_document[]"></td>
            </tr>`);
        return false;
    }

</script>

<script>
    CKEDITOR.replace('pre_production_process', {});
    CKEDITOR.replace('production_process', {});
    CKEDITOR.replace('post_production_process', {});
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/forms/sop_production_form.blade.php ENDPATH**/ ?>