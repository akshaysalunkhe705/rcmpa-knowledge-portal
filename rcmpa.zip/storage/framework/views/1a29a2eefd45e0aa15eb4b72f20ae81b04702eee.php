<div class="row">
    <div class="col-md-3">
        <label for="document_number">Document Number</label>
        <input type="text" name="document_number" class="form-control" value="<?php echo e($documentNumber); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="created_date">Created Date</label>
        <input type="text" name="created_date" class="form-control" value="<?php echo e($createdDate); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="version_no">Version No</label>
        <input type="text" name="version_no" class="form-control" value="<?php echo e($versionNo); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="capa_number">Capa Number</label>
        <input type="text" name="capa_number" class="form-control" value="<?php echo e($capaNumber); ?>" readonly>
    </div>
</div>
<br>
<div class="row">
    <div class="col-md-3">
        <label for="revision_date">Revision Date</label>
        <input type="text" name="revision_date" class="form-control" value="<?php echo e($revisionDate); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="prepared_by">Prepared By</label>
        <input type="text" name="prepared_by" class="form-control" value="<?php echo e($preparedBy); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="approved_by">Approved By</label>
        <input type="text" name="approved_by" class="form-control" value="<?php echo e($approvedBy); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="location">Location</label>
        <input type="text" name="location" class="form-control" value="<?php echo e($location); ?>" readonly>
    </div>
</div>
<br>
<div class="row">
    <div class="col-md-3">
        <label for="department">Department</label>
        <input type="text" name="department" class="form-control" value="<?php echo e($department); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="main_document_id">Main Document Id</label>
        <input type="text" name="main_document_id" class="form-control" value="<?php echo e($mainDocumentId); ?>" readonly>
    </div>
    <div class="col-md-3">
        <label for="sub_document_id">Sub Document Id</label>
        <input type="text" name="sub_document_id" class="form-control" value="<?php echo e($subDocumentId); ?>" readonly>
    </div>
</div>
<br>
<hr>
<?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/components/document-form-header-component.blade.php ENDPATH**/ ?>