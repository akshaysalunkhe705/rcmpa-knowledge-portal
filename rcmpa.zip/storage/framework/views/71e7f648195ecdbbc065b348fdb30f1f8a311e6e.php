<?php $__env->startSection('main_container'); ?>
<?php
$documentData = $dataSet->document_details;
?>
    <form action="<?php echo e(url('hod/capa_actions/process_and_flow_control/')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <hr>
        <div>
            <label for="objective">Objective</label>
            <input type="text" name="objective" class="form-control" value="<?php echo e($documentData['objective']); ?>" disabled>
        </div>
        <br>

        <label for="department_and_thirdparty_involvement">Department And Thirdparty Involvement </label>
        <table class="table table-bordered">
            <tbody id="department_and_thirdparty_involvement_tr">
                <?php if($documentData != null): ?>
                    <tr>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $documentData['department_and_third_party_involvement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($i % 3) == 0): ?>
                                <?php $i=0; ?>
                                </tr><tr>
                            <?php endif; ?>
                            <?php $i++ ?>
                            <td>
                                <input type="text" name="department_and_third_party_involvement[]"
                                    id="department_and_third_party_involvement" class="form-control"
                                    value="<?php echo e($item); ?>" disabled>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <label for="list_of_documnet_involved">List Of Document Involved</label>
        <button class="btn btn-primary" onclick="js:add_list_of_documnet_involved();">+</button>
        <table class="table table-bordered">
            <tbody id="list_of_documnet_involved">
                <?php if($documentData != null): ?>
                    <tr>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $documentData['list_of_document_involved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($i % 3) == 0): ?>
                                <?php $i=0; ?>
                                </tr><tr>
                            <?php endif; ?>
                            <?php $i++ ?>
                            <td>
                                <input type="text" name="list_of_document_involved[]" id="list_of_document_involved"
                                    class="form-control" value="<?php echo e($item); ?>" disabled>
                            </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <label for="process_description">Process Description</label>
        <button class="btn btn-primary" onclick="js:add_process_description();">+</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>desciption</th>
                    <th>Units</th>
                    <th>Desgination Responsible</th>
                    <th>Document In Use</th>
                    <th>Special Remarks</th>
                </tr>
            </thead>
            <tbody id="process_description">
                <?php if($documentData != null): ?>
                    <?php for($i = 0; $i < count($documentData['process_description']['description']); $i++): ?>
                        <tr>
                            <td>
                                <input type="text" name="process_description[]" id="process_description"
                                    class="form-control" value="<?php echo e($documentData['process_description']['description'][$i]); ?>" disabled>
                            </td>
                            <td>
                                <input type="text" name="units[]" id="units" class="form-control"
                                    value="<?php echo e($documentData['process_description']['unit'][$i]); ?>" disabled>
                            </td>
                            <td>
                                <input type="text" name="desgination_responsible[]" id="desgination_responsible"
                                    class="form-control"
                                    value="<?php echo e($documentData['process_description']['designation_responsibility'][$i]); ?>" disabled>
                            </td>
                            <td>
                                <input type="text" name="document_in_use[]" id="document_in_use" class="form-control"
                                    value="<?php echo e($documentData['process_description']['document_in_use'][$i]); ?>" disabled>
                            </td>
                            <td>
                                <input type="text" name="special_remarks[]" id="special_remarks" class="form-control"
                                    value="<?php echo e($documentData['process_description']['spacial_remarks'][$i]); ?>" disabled>
                            </td>
                        </tr>
                    <?php endfor; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <div class="row">
            <div class="col-md-3">
                <label for="reference_document_urls">Reference Document Upload</label>
                <input type="file" name="reference_document_urls" class="form-control" multiple>
            </div>
        </div>

        <br>
        <hr>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormFooterComponent::class, ['status' => ''.e($dataSet->status).'','statusByAdmin' => ''.e($dataSet->status_by_admin).'','statusBySuperAdmin' => ''.e($dataSet->status_by_super_admin).'','rejectNote' => ''.e($dataSet->reject_note).'','removedNote' => ''.e($dataSet->removed_note).'']); ?>
<?php $component->withName('document-form-footer-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38)): ?>
<?php $component = $__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38; ?>
<?php unset($__componentOriginalcf322435631f5cdfbcedfb515ea0f57b96118a38); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <br>
        <input type="submit" name="SAVE" class="btn btn-primary" value="SAVE">
        <input type="submit" name="SUBMIT" class="btn btn-primary" value="SUBMIT">
    </form>
    <br>
    <hr>
    <br>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('./layouts/formview_layout',
[
'title' => 'CAPA',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/document_form_views/process_and_flow_control_form.blade.php ENDPATH**/ ?>