<?php
use App\Models\DepartmentModel;
use App\Models\MainDocumentTitleModel;
use App\Models\SubDocumentTitleModel;
use App\Models\UserDocumentPermissionModel;
?>




<?php $__env->startSection('main_container'); ?>
    <div class="row">
        <div class="col-md-6 border p-2">
            <label>Department : </label>
            <span><?php echo e($user->department); ?></span>
        </div>
        <div class="col-md-6 border p-2">
            <label>Role : </label>
            <span><?php echo e($user->role); ?></span>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-4 border p-2">
            <label>Name : </label>
            <span><?php echo e($user->name); ?></span>
        </div>
        <div class="col-md-4 border p-2">
            <label>User Name : </label>
            <span><?php echo e($user->username); ?></span>
        </div>
        
    </div>

    <br><br>



    <?php $__currentLoopData = $departmentDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div onclick="js:toggleDepartmentSlide(<?php echo e($department->id); ?>)" class="border p-2 bg-danger"
            style="font-weight:bold;">
            <h4 style="color:white;"><?php echo e($department->department_name); ?></h4>
        </div>
        <div id="department-<?php echo e($department->id); ?>" class=" border p-2" style="background-color:rgb(179, 179, 179)">
            <?php $__currentLoopData = $FormsModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formMaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $masterDocumentsCount = 0; ?>
                <div class="masterForm-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>">
                    <div onclick="js:toggleFormMasterSlide(<?php echo e($formMaster->id); ?>)" class="border p-2 bg-info">
                        <h5><?php echo e($formMaster->form_name); ?></h5>
                    </div>
                    <div id="form-master-<?php echo e($formMaster->id); ?>" class="form-master border p-2"
                        style="background-color:white;">
                        <?php $mainDocumentDataset = MainDocumentTitleModel::where('department_id',
                        $department->id)
                        ->where('form_id', $formMaster->id)
                        ->get(); ?>
                        <?php $__currentLoopData = $mainDocumentDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $masterDocumentsCount++; ?>
                            <h5> <?php echo e($mainDocument->document_name); ?> </h5>
                            <?php $subDocumentDataset = SubDocumentTitleModel::where('department_id',
                            $department->id)
                            ->where('main_document_id', $mainDocument->id)
                            ->get(); ?>
                            
                            <?php $__currentLoopData = $subDocumentDataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $CREATE_UPDATE_ROLLBACK_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id',
                                $user->id)
                                ->where('permission_type', 'CREATE_UPDATE_ROLLBACK_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $VIEW_ACTIVE_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id', $user->id)
                                ->where('permission_type', 'VIEW_ACTIVE_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $DEACTIVE_REACTIVE_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id',
                                $user->id)
                                ->where('permission_type', 'DEACTIVE_REACTIVE_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $VIEW_PENDING_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id', $user->id)
                                ->where('permission_type', 'VIEW_PENDING_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $VIEW_REJECTED_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id', $user->id)
                                ->where('permission_type', 'VIEW_REJECTED_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $VIEW_ARCHIVE_DOC_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id', $user->id)
                                ->where('permission_type', 'VIEW_ARCHIVE_DOC')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                $CAPA_STATUS_PERMISSION_STATUS = UserDocumentPermissionModel::where('user_id', $user->id)
                                ->where('permission_type', 'CAPA_STATUS')
                                ->where('department_id', $department->id)
                                ->where('form_id', $formMaster->id)
                                ->where('main_document_id', $mainDocument->id)
                                ->where('sub_document_id', $subDocument->id)
                                ->first();
                                ?>
                                <div class="border p-3">
                                    <b><?php echo e($mainDocument->main_document_title); ?> - ( <?php echo e($subDocument->sub_document_title); ?> ) </b>
                                    <br><br>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <input type="checkbox"
                                                id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-ALL"
                                                onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'ALL');">
                                            SELECT ALL <br>
                                            <input type="checkbox"
                                                id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-CREATE_UPDATE_ROLLBACK_DOC"
                                                onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'CREATE_UPDATE_ROLLBACK_DOC');" <?= $CREATE_UPDATE_ROLLBACK_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> Create | Update | Rollback
                                            </div>

                                            <div class="col-md-3">
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-VIEW_ACTIVE_DOC" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'VIEW_ACTIVE_DOC');" <?= $VIEW_ACTIVE_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> View Active Docs <br>
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-DEACTIVE_REACTIVE_DOC" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'DEACTIVE_REACTIVE_DOC');" <?= $DEACTIVE_REACTIVE_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> Deactivate | Reactive Docs
                                            </div>

                                            <div class="col-md-3">
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-VIEW_PENDING_DOC" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'VIEW_PENDING_DOC');" <?= $VIEW_PENDING_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> View Pending Docs <br>
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-VIEW_REJECTED_DOC" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'VIEW_REJECTED_DOC');" <?= $VIEW_REJECTED_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> View Rejected Docs
                                            </div>

                                            <div class="col-md-3">
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-VIEW_ARCHIVE_DOC" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'VIEW_ARCHIVE_DOC');" <?= $VIEW_ARCHIVE_DOC_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> View Archive Docs <br>
                                                <input type="checkbox" id="checkbox-id-<?php echo e($user->id); ?>-<?php echo e($department->id); ?>-<?php echo e($formMaster->id); ?>-<?php echo e($mainDocument->id); ?>-<?php echo e($subDocument->id); ?>-CAPA_STATUS" onchange="js:assignRoleToUser(id, <?php echo e($user->id); ?>, <?php echo e($department->id); ?>, <?php echo e($formMaster->id); ?>, <?php echo e($mainDocument->id); ?>, <?php echo e($subDocument->id); ?>, 'CAPA_STATUS');" <?= $CAPA_STATUS_PERMISSION_STATUS != null ? 'checked' : 'none' ?>> View CAPA Status
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br><br>
                    </div>
                    <?php if($masterDocumentsCount == 0): ?>
                        <style>
                            .masterForm-<?= $department->id ?>-<?= $formMaster->id ?>{
                                display: none;
                            }

                        </style>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <style>
            label {
                font-size: 1.2em;
            }

        </style>

        <script>
            function assignRoleToUser(checkbox_id, user_id, department_id, form_id, main_document_id, sub_document_id, action) {
                if($("#"+checkbox_id).prop("checked") == true)
                {
                    $.get('<?php echo e(url('admin/user_document_permissions/set_document_action')); ?>',{
                        'user_id':user_id,
                        'department_id':department_id,
                        'form_id':form_id,
                        'main_document_id':main_document_id,
                        'sub_document_id':sub_document_id,
                        'permission_type':action,
                    },function(response) {
                        console.log(response);
                    });
                }else{
                    $.get('<?php echo e(url('admin/user_document_permissions/unset_document_action')); ?>',{
                        'user_id':user_id,
                        'department_id':department_id,
                        'form_id':form_id,
                        'main_document_id':main_document_id,
                        'sub_document_id':sub_document_id,
                        'permission_type':action,
                    },function(response) {
                        console.log(response);
                    });
                }
            }

            function toggleDepartmentSlide(id) {
                $("#department-" + id).slideToggle();
            }

            function toggleFormMasterSlide(id) {
                $("#form-master-" + id).slideToggle();
            }

            function checked_all(id) {
                $("#curd-" + id).prop('checked', true);
                $("#view_active-" + id).prop('checked', true);
                $("#view_rejected-" + id).prop('checked', true);
                $("#view_archive-" + id).prop('checked', true);
                $("#view_pending-" + id).prop('checked', true);
                $("#view_deactivate-" + id).prop('checked', true);
                $("#capa_status-" + id).prop('checked', true);
            }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layouts/layout',
[
'title' => 'User',
'heading' => 'User',
'breadcrumb1' => 'user',
'breadcrumb2' => $user->name,
'nav_status' => 'user',
'sub_nav_status' => 'user-fetch',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/user/detail.blade.php ENDPATH**/ ?>