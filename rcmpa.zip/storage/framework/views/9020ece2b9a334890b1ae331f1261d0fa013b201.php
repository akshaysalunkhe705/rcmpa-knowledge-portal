

<?php $__env->startSection('main_container'); ?>

<table class="table">
    <tr>
        <th>CAPA No</th>
        <th>Version</th>
        <th>Location/Department</th>
        <th>Form</th>
        <th>Master Document Title</th>
        <th>Sub Document Title</th>
        <th>Action</th>
    </tr>

    <?php $__currentLoopData = $document_dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->capa_number); ?></td>
            <td><?php echo e($item->version_number); ?></td>
            <td><?php echo e($item->fetchLocation($item->location_id)); ?> / <?php echo e($item->fetchDepartment($item->department_id)); ?></td>
            <td><?php echo e($item->fetchForm($item->form_id)); ?></td>
            <td><?php echo e($item->fetchMainDocumentTitle($item->main_document_id)); ?></td>
            <td><?php echo e($item->fetctSubDocumentTitle($item->sub_document_id)); ?></td>
            <td>
                <a href="" class="btn">View</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layouts/layout',
[
'title' => 'Document View',
'heading' => 'Document View',
'breadcrumb1' => 'Document View',
'breadcrumb2' => 'Archived Document',
'nav_status' => 'document_view',
'sub_nav_status' => 'document_view-archived',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/document_views/archived_document.blade.php ENDPATH**/ ?>