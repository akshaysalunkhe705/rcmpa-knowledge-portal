<li class="sidebar-menu-item <?php if($nav_status=='doument-list' ): ?> active open <?php endif; ?>">
    <a class="sidebar-menu-button js-sidebar-collapse" href="<?php echo e(url('user/document_list')); ?>">
        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">format_shapes</span>
        DOCUMENTS
    </a>
</li><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/layouts/navs/user.blade.php ENDPATH**/ ?>