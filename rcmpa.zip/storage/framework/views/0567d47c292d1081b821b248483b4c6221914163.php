<?php $__env->startSection('main_container'); ?>
<?php
$documentData = $dataSet->document_details;
?>
    <form action="<?php echo e(url('hod/capa_actions/msds')); ?>/<?php echo e($dataSet->id); ?>" method="post">
        <input type="hidden" name="document_id" value="<?php echo e($dataSet->id); ?>">
        <?php echo csrf_field(); ?>
        <div style="border:1px solid; padding:1%;">
            <?php if (isset($component)) { $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DocumentFormHeaderComponent::class, ['documentNumber' => ''.e($dataSet->document_number).'','createdDate' => ''.e($dataSet->created_date).'','versionNo' => ''.e($dataSet->version_number).'','capaNumber' => ''.e($dataSet->capa_number).'','revisionDate' => ''.e($dataSet->revision_date).'','preparedBy' => ''.e($dataSet->prepared_by).'','approvedBy' => ''.e($dataSet->approved_by).'','location' => ''.e($dataSet->fetchLocation($dataSet->location_id)).'','department' => ''.e($dataSet->fetchDepartment($dataSet->department_id)).'','mainDocumentId' => ''.e($dataSet->fetchMainDocumentTitle($dataSet->main_document_id)).'','subDocumentId' => ''.e($dataSet->fetctSubDocumentTitle($dataSet->sub_document_id)).'']); ?>
<?php $component->withName('document-form-header-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9)): ?>
<?php $component = $__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9; ?>
<?php unset($__componentOriginalc70bbb126923da26dbb6a59a7da43b346c9fefc9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <br>
        <label for="identification">identification</label>
        <div class="row">
            <div class="col-md-4">Product Idenitifer</div>
            <div class="col-md-4">
                <input type="text" name="product_identification" id="product_identification" class="form-control" value="<?php echo e($documentData['identification']['product_identification']); ?>" disabled>
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Product Code</div>
            <div class="col-md-4">
                <input type="text" name="product_code" id="product_code" class="form-control" value="<?php echo e($documentData['identification']['product_code']); ?>" disabled>
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Physical Appearance</div>
            <div class="col-md-4">
                <input type="text" name="physical_appearance" id="physical_appearance" class="form-control" value="<?php echo e($documentData['identification']['physical_appearance']); ?>" disabled>
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">CAS Number</div>
            <div class="col-md-4">
                <input type="text" name="CAS_number" id="CAS_number" class="form-control" value="<?php echo e($documentData['identification']['CAS_number']); ?>" disabled>
            </div>
        </div><br>
        <div class="row">
            <div class="col-md-4">Relevant Identified Uses Of Substance</div>
            <div class="col-md-4">
                <input type="text" name="relevant_identified_uses_of_substance"
                    id="relevant_identified_uses_of_substance" class="form-control" value="<?php echo e($documentData['identification']['relevant_identified_uses_of_substance']); ?>" disabled>
            </div>
        </div>

        <br><br>
        <label for="hazards_identification">Hazards Identification</label><br>
        <?php echo e($documentData['hazards_identification']); ?>

        <br><br>
        <label for="composition_information_or_ingredients">Composition Information/Ingredients</label><br>
        <?php echo e($documentData['composition_information_or_ingredients']); ?>

        <br><br>
        <label for="first_and_measures">First And Measures</label><br>
        <?php echo e($documentData['first_and_measures']); ?>

        <br><br>
        <label for="firefighting_measures">Firefighting Measures</label><br>
        <?php echo e($documentData['firefighting_measures']); ?>

        <br><br>
        <label for="accidental_release_measures">Accidental Release Measures</label><br>
        <?php echo e($documentData['accidental_release_measures']); ?>

        <br><br>
        <label for="handling_and_storage">Handling And Storage</label><br>
        <?php echo e($documentData['handling_and_storage']); ?>

        <br><br>
        <label for="exposure_control_or_personal_protection">Exposure Control/Personal Protection</label><br>
        <?php echo e($documentData['exposure_control_or_personal_protection']); ?>

        <br><br>
        <label for="physical_and_chemical_properties">Physical And Chemical Properties</label><br>
        <?php echo e($documentData['physical_and_chemical_properties']); ?>

        <br><br>
        <label for="stability_and_reactivity">Stability And Reactivity</label><br>
        <?php echo e($documentData['stability_and_reactivity']); ?>

        <br><br>
        <label for="toxiocological_information">Toxiocological Information</label><br>
        <?php echo e($documentData['toxiocological_information']); ?>


        
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('./layouts/formview_layout',
[
'title' => 'CAPA',
]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\rcmpa\resources\views/document_form_views/msds_form.blade.php ENDPATH**/ ?>